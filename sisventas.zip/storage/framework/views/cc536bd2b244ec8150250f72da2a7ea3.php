

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Registrar nueva Venta<b style="color:#1E90FF;"></b></h1>
<hr style="background-color: #C0C0C0; height: 1px; border: none;">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card card-outline card-success">
            <div class="card-header">
                <h3 class="card-title">Ingrese los datos</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('/admin/ventas/create')); ?>" id="form_venta" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="cantidad">Cantidad</label><b style="color: crimson;"> *</b>
                                        <input type="number" class="form-control" id="cantidad" required value="1" style="text-align: center; background-color: rgba(233, 231, 16, 0.15);">
                                        <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="codigo">Código</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                                        </div>
                                        <input id="codigo" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div style="height: 32px;"></div>
                                        <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-search"></i></button>
                                        <!-- #boton de buscar -->

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Listado de productos</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <!--TABLA DE PRODUCTOS-->

                                                        <table id="mitabla" class="table table-striped table-bordered table-hover table-sm table-responsive">
                                                            <thead class="thead-light">
                                                                <tr>
                                                                    <th scope="col">Nro</th>
                                                                    <th scope="col" style="text-align: center;">Agregar a compra</th>
                                                                    <th scope="col">Categoría</th>
                                                                    <th scope="col">Código producto</th>
                                                                    <th scope="col">Nombre producto</th>
                                                                    <th scope="col">Descripción</th>
                                                                    <th scope="col">Stock</th>
                                                                    <th scope="col">Precio compra</th>
                                                                    <th scope="col">Precio Venta</th>
                                                                    <th scope="col">Imagen del producto</th>



                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $contador = 1;
                                                                ?>
                                                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($contador++); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;">
                                                                        <button type="button" class=" btn btn-info seleccionar-btn" data-id="<?php echo e($producto->codigo); ?>"><i class="fas fa-shopping-cart"> </i>Seleccionar</button>
                                                                    </td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($producto->categoria->nombre); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($producto->codigo); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($producto->nombre); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($producto->descripcion); ?></td>
                                                                    <td style="text-align:center;  vertical-align:middle; background-color:rgba(233, 231, 16, 0.15)"><?php echo e($producto->stock); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;">$ <?php echo e(number_format($producto->precio_compra, 0, ',', '.')); ?></td>

                                                                    <td style="text-align:center; vertical-align:middle;">$ <?php echo e(number_format($producto->precio_venta, 0, ',', '.')); ?></td>

                                                                    <td style="text-align:center; vertical-align:middle;">
                                                                        <img src="<?php echo e(asset('storage/'.$producto->imagen)); ?>" alt="Imagen No Disponible" width="80px" style="border: 5px solid #00BC8C; box-shadow: 5px 0px 5px 0px #00BC8C;">
                                                                    </td>

                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>


                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <a href="<?php echo e(url('/admin/productos/create')); ?>" class="btn btn-success" type="button"><i class="fas fa-plus"></i></a>

                                        
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <table class="table table-sm table-striped table-bordered table-hover">
                                    <thead>
                                        <tr style="background-color: #28a745; color: #ffffff;">
                                            <th>Nro</th>
                                            <th>Código</th>
                                            <th>Cantidad</th>
                                            <th>Nombre</th>
                                            <th>Costo</th>
                                            <th>Total</th>
                                            <th style="text-align: center;">Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $cont = 1;
                                        $total_cantidad = 0;
                                        $total_venta = 0; ?>
                                        <?php $__currentLoopData = $tmp_ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp_venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td style="text-align: center;"><?php echo e($cont++); ?></td>
                                            <td style="text-align: center;"><?php echo e($tmp_venta->producto->codigo); ?></td>
                                            <td style="text-align: center;"><?php echo e($tmp_venta->cantidad); ?></td>
                                            <td style="text-align: center;"><?php echo e($tmp_venta->producto->nombre); ?></td>
                                            <td style="text-align: center;">
                                                $ <?php echo e(number_format($tmp_venta->producto->precio_venta, 0, ',', '.')); ?>

                                            </td>
                                            <td style="text-align: center;">
                                                $ <?php echo e(number_format($costo = $tmp_venta->cantidad * $tmp_venta->producto->precio_venta, 0, ',', '.')); ?>

                                            </td>
                                            <td style="text-align: center;">
                                                <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="<?php echo e($tmp_venta->id); ?>" title="Eliminar">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
                                        $total_cantidad += $tmp_venta->cantidad;
                                        $total_venta+=$costo;
                                        ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfooter>
                                        <tr style="background-color: #e8f5e9; color: #333333;">
                                            <td colspan="2" style="text-align: right;"><b>Total Cantidad Productos: </b></td>
                                            <td style="text-align: center;">
                                                <b><?php echo e($total_cantidad); ?></b>
                                            </td>
                                            <td colspan="2" style="text-align: right;"><b>Total de la Venta: </b></td>
                                            <td style="text-align: center;">
                                                <b>$ <?php echo e(number_format($total_venta,0,',','.')); ?></b>
                                            </td>
                                        </tr>
                                    </tfooter>

                                </table>
                            </div>

                        </div>

                        <div class="col-md-4">
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-info " data-toggle="modal" data-target="#exampleModal_cliente"><i class="fas fa-search"></i> Buscar Clientes</button>
                                    <button type="button" class="btn btn-success " data-toggle="modal" data-target="#exampleModal_crear_cliente"><i class="fas fa-plus"></i></button>
                                    <div class="form-group">
                                        <div style="height: 32px;"></div>

                                        <!-- #boton de buscar -->

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal_cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Listado de Clientes</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <!--TABLA DE PRODUCTOS-->

                                                        <table id="mitabla2" class="table table-striped table-bordered table-hover table-sm table-responsive">
                                                            <thead class="thead-light">
                                                                <tr>
                                                                    <th scope="col">Nro</th>
                                                                    <th scope="col" style="text-align: center;">Acción</th>
                                                                    <th scope="col">Nombtre Cliente</th>
                                                                    <th scope="col">nit/Rut</th>
                                                                    <th scope="col">Teléfono Contacto</th>
                                                                    <th scope="col">Correo Electronico</th>


                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $contador = 1;
                                                                ?>
                                                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($contador++); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;">
                                                                        <button type="button" class=" btn btn-info seleccionar-btn-cliente" data-id="<?php echo e($cliente->id); ?>" data-nit="<?php echo e($cliente->nit_codigo); ?>" data-nombrecliente="<?php echo e($cliente->nombre_cliente); ?>"><i class="fas fa-truck-fast"> </i> Seleccionar</button>
                                                                    </td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($cliente->nombre_cliente); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($cliente->nit_codigo); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($cliente->telefono); ?></td>
                                                                    <td style="text-align:center; vertical-align:middle;"><?php echo e($cliente->email); ?></td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>


                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal fade" id="exampleModal_crear_cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Registar un nuevo Clientes</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">


                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="nombre_cliente">nombre cliente </label><b style="color: crimson;"> *</b>
                                                                    <input type="text" class="form-control" id="nombre_cliente" value="<?php echo e(old('nombre_cliente')); ?>">
                                                                    <?php $__errorArgs = ['nombre_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <small style="color:red;"><?php echo e($message); ?></small>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="nit_codigo">NIT /codigo Cliente</label><b style="color: crimson;"> *</b>
                                                                    <input type="text" class="form-control" id="nit_codigo" value="<?php echo e(old('nit_codigo')); ?>">
                                                                    <?php $__errorArgs = ['nit_codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <small style="color:red;"><?php echo e($message); ?></small>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="telefono">Teléfono</label><b style="color: crimson;"> *</b>
                                                                    <input type="text" class="form-control" id="telefono" value="<?php echo e(old('telefono')); ?>">
                                                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <small style="color:red;"><?php echo e($message); ?></small>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="email">Correo Electronico</label><b style="color: crimson;"> *</b>
                                                                    <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>">
                                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <small style="color:red;"><?php echo e($message); ?></small>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr style="background-color: #009670;">
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                    </div>


                                </div>

                            </div>
                            <hr style="background-color: #00BC8C; height: 1px; border: none;">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="nombre Cliente">Nombre del Cliente</label>
                                    <input type="text" class="form-control" id="nombre_cliente_select" required value="S/N">
                                    <input type="text" class="form-control" readonly id="id_cliente" name="cliente_id" hidden>
                                </div>
                                <div class="col-md-6">
                                    <label for="nit Cliente">NIT / Código / Rut del Cliente</label>
                                    <input type="text" class="form-control" id="nit_cliente_select" required value="0">
                                </div>
                            </div>
                            <hr style="background-color: #00BC8C; height: 1px; border: none;">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="fecha">Fecha Venta</label><b style="color: crimson;"> *</b>
                                        <input type="date" class="form-control" name="fecha" required value="<?php echo e(old('fecha', now()->toDateString())); ?>">
                                        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group" style="text-align: center;">
                                        <label for="precio_total">Precio Total a pagar</label><b style="color: crimson;"> *</b>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">$ </span>
                                            </div>
                                            <input type="text" style="text-align: center; background-color: #3c8dbc; border: 1px solid #8da5b8;"
                                                class="form-control" name="precio_total" required
                                                value="<?php echo e($total_venta); ?>">

                                            <?php $__errorArgs = ['precio_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small style="color:red;"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

            </div>

            <hr style="background-color: #00BC8C;">
            <div class="row">
                <div class="col-md-12 d-flex justify-content-center">
                    <div class="form-group">
                        <button type="submit" class="btn btn-success" style="background-color: success; color:white;"><i class="fas fa-shopping-cart"></i> Registrar Venta</button>
                        <a href="<?php echo e(url('/admin/ventas')); ?>" type="submit" class="btn btn-secondary" style="background-color: secondary; color:white;"><i class="fas fa-undo"></i> volver</a>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<!--PRELOAD PERSONALIZAOD-->
<?php $__env->startSection('preloader'); ?>
<div class="text-center">
    <!-- Logo o ícono de carga de tecnología -->
    <div class="mb-4">
        <i class="fas fa-4x fa-spin fa-cogs text-primary"></i> <!-- Icono de engranaje (tecnológico) -->
    </div>

    <!-- Texto de carga -->
    <h4 class="mt-4 text-dark">Cargando tu tienda de tecnología</h4>
    <p class="text-muted">Estamos preparando los mejores productos para ti...</p>

    <!-- Barra de progreso (opcional para mejorar el efecto visual) -->
    <div class="progress mt-3" style="height: 10px;">
        <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 70%"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    /* GUARDAR CLIENTE NUEVO */

    function guardar_cliente() {
        const data = {
            nombre_cliente: $('#nombre_cliente').val(),
            nit_codigo: $('#nit_codigo').val(),
            telefono: $('#telefono').val(), // Corrección aquí
            email: $('#email').val(), // Corrección aquí
            _token: '<?php echo e(csrf_token()); ?>'
        };

        //console.log("Datos a enviar:", data); // Verificación en consola

        $.ajax({
            url: '<?php echo e(route("admin.ventas.cliente.store")); ?>',
            type: 'POST',
            data: data,
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        position: "top-end",
                        icon: "success",
                        title: "Se registró el Cliente",
                        showConfirmButton: false,
                        timer: 1500
                    });
                    location.reload();
                } else {
                    alert('No se encotro al CLIENTE');
                }
            },
            error: function(xhr, status, error) {
                alert('Error: No se pudo registrar al cliente');
            }
        });
    }



    /*SELECCIONAR CLIENTE*/
    $('.seleccionar-btn-cliente').click(function() {
        var id_cliente = $(this).data('id');
        var nombre_cliente = $(this).data('nombrecliente');
        var nit_codigo = $(this).data('nit');
        //alert(nombre_cliente);
        //alert(empresa);


        $('#nombre_cliente_select').val(nombre_cliente);
        $('#nit_cliente_select').val(nit_codigo);
        $('#id_cliente').val(id_cliente);
        $('#exampleModal_cliente').modal('hide');

    });

    /*SELECCIONAR CLIENTE*/
    $('.seleccionar-btn').click(function() {
        var id_producto = $(this).data('id')
        //alert(id_producto);
        $('#codigo').val(id_producto);
        $('#exampleModal').modal('hide');
        $('#exampleModal').on('hidden.bs.modal', function() {
            $('#codigo').focus();
        });
    });


    /*Eliminar productos*/
    $('.delete-btn').click(function() {
        var id = $(this).data('id');
        if (id) {
            $.ajax({
                url: "<?php echo e(url('/admin/ventas/create/tmp')); ?>/" + id,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    _method: 'DELETE',
                },
                success: function(response) {
                    // Verificar si el if está en minúsculas
                    if (response.success) {
                        Swal.fire({
                            position: "top-end",
                            icon: "error",
                            title: "No se eliminó el producto",
                            showConfirmButton: false,
                            timer: 1500
                        });
                        location.reload();
                    } else {
                        Swal.fire({
                            position: "top-end",
                            icon: "success",
                            title: "¡Producto eliminado!",
                            showConfirmButton: false,
                            timer: 1500
                        });
                        location.reload();
                    }
                },
                error: function(error) {
                    alert("Error en la solicitud");
                }
            });
        }
    });

    /*Agregar a la Tabla la Venta*/


    $('#codigo').focus();
    $('#form_venta').on('keypress', function(e) {
        if (e.keyCode === 13) {
            e.preventDefault();
        }
    });

    $('#codigo').on('keyup', function(e) {
        if (e.which === 13) {
            var codigo = $(this).val();
            var cantidad = $('#cantidad').val();
            //alert(codigo);
            if (codigo.length > 0) {
                $.ajax({
                    url: "<?php echo e(route('admin.ventas.tmp_ventas')); ?>",
                    method: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        codigo: codigo,
                        cantidad: cantidad
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                position: "top-end",
                                icon: "success",
                                title: response.message,
                                showConfirmButton: false,
                                timer: 1500
                            });
                            location.reload();
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(error) {
                        alert(response.message + error);
                    }
                });
            }
        }
    });
</script>
<script>
    //Mi tabla 1
    $('#mitabla').DataTable({
        "pageLength": 5,
        "language": {
            "emptyTable": "No hay Información para visualizar",
            "info": "Mostrando de _START_ a _END_ Entradas, de un total de _TOTAL_ entradas disponibles",
            "infoEmpty": "Mostrando 0 a 0 de 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ Entradas totales)",
            "infoPostFix": "",
            "thousands": "",
            "lengthMenu": "Mostrar  _MENU_  Entradas",
            "loadingRecords": "Cargando . . ",
            "processing": "Procesando. . . ",
            "search": "Buscar: ",
            "zeroRecords": "Sin resultados en la busqueda",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
    });

    //Mi tabla 2
    $('#mitabla2').DataTable({
        "pageLength": 5,
        "language": {
            "emptyTable": "No hay Información para visualizar",
            "info": "Mostrando de _START_ a _END_ Entradas, de un total de _TOTAL_ entradas disponibles",
            "infoEmpty": "Mostrando 0 a 0 de 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ Entradas totales)",
            "infoPostFix": "",
            "thousands": "",
            "lengthMenu": "Mostrar  _MENU_  Entradas",
            "loadingRecords": "Cargando . . ",
            "processing": "Procesando. . . ",
            "search": "Buscar: ",
            "zeroRecords": "Sin resultados en la busqueda",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views/admin/ventas/create.blade.php ENDPATH**/ ?>