<?php $layoutHelper = app('JeroenNoten\LaravelAdminLte\Helpers\LayoutHelper'); ?>
<?php $preloaderHelper = app('JeroenNoten\LaravelAdminLte\Helpers\PreloaderHelper'); ?>

<?php $__env->startSection('adminlte_css'); ?>
<?php echo $__env->yieldPushContent('css'); ?>
<?php echo $__env->yieldContent('css'); ?>

<!-- CSS adicional -->
<style>
    /* Hover effect for ROLES */
    .info-box .info-box-icon.bg-info:hover {
        background-color: #17a2b8 !important;
        /* Color info para el hover */
        transform: scale(1.1);
        /* Aumenta ligeramente el tamaño del icono */
    }

    /* Hover effect for USUARIOS */
    .info-box .info-box-icon.bg-success:hover {
        background-color: #28a745 !important;
        /* Color success para el hover */
        transform: scale(1.1);
        /* Aumenta ligeramente el tamaño del icono */
    }

    /* Hover effect for CATEGORIAS */
    .info-box .info-box-icon.bg-warning:hover {
        background-color: #ffc107 !important;
        /* Color warning para el hover */
        transform: scale(1.1);
        /* Aumenta ligeramente el tamaño del icono */
    }

    /* Hover effect for PRODUCTOS */
    .info-box .info-box-icon.bg-warning:hover {
        background-color: #FF7F50 !important;
        /* Color Coral para el hover */
        transform: scale(1.1);
        /* Aumenta ligeramente el tamaño del icono */
    }

    /* Hover effect for PROVEEDORES */
    .info-box .info-box-icon.bg-warning:hover {
        background-color: #FF6347 !important;
        /* Color Coral para el hover */
        transform: scale(1.1);
        /* Aumenta ligeramente el tamaño del icono */
    }

    /* Estilo para los iconos para que el hover se vea bien */
    .info-box .info-box-icon {
        transition: background-color 0.3s ease, transform 0.3s ease;
        /* Suaviza el cambio de color y tamaño */
    }

    .zoomP {
        /*Aumentamos el ancho y el alto durante 2 segundos */
        transition: width 1.1s, height 1.1s, transform 1.1s;
        -moz-transition: width 1.1s, height 1.1s, -moz-transform 1.1s;
        -webkit-transition: width 1.1s, height 1.1s, -webkit-transform 1.1s;
        -o-transition: width 1.1s, height 1.1s, -moz-transform 1.1s;
        border: 1px solid #c0c0c0;
        box-shadow: #c0c0c0 0px 5px 5px 0px;
    }

    .zoomP:hover {
        /*Transdoermamos el elemento al pasar el mouse por encima al doble de tamaño */
        transform: scale(1.05);
        -webkit-transform: scale(1.05);
        transform: scale(1.05);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('classes_body', $layoutHelper->makeBodyClasses()); ?>

<?php $__env->startSection('body_data', $layoutHelper->makeBodyData()); ?>

<?php $__env->startSection('body'); ?>
<div class="wrapper">

    
    <?php if($preloaderHelper->isPreloaderEnabled()): ?>
    <?php echo $__env->make('adminlte::partials.common.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($layoutHelper->isLayoutTopnavEnabled()): ?>
    <?php echo $__env->make('adminlte::partials.navbar.navbar-layout-topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <?php echo $__env->make('adminlte::partials.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if(!$layoutHelper->isLayoutTopnavEnabled()): ?>
    <?php echo $__env->make('adminlte::partials.sidebar.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if(empty($iFrameEnabled)): ?>
    <?php echo $__env->make('adminlte::partials.cwrapper.cwrapper-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <?php echo $__env->make('adminlte::partials.cwrapper.cwrapper-iframe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if (! empty(trim($__env->yieldContent('footer')))): ?>
    <?php echo $__env->make('adminlte::partials.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($layoutHelper->isRightSidebarEnabled()): ?>
    <?php echo $__env->make('adminlte::partials.sidebar.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
<?php echo $__env->yieldPushContent('js'); ?>
<?php echo $__env->yieldContent('js'); ?>
<?php $__env->stopSection(); ?>

<!--PRELOAD PERSONALIZAOD-->
<?php $__env->startSection('preloader'); ?>
<div class="text-center">
    <!-- Logo o ícono de carga de tecnología -->
    <div class="mb-4">
        <i class="fas fa-4x fa-spin fa-cogs text-primary"></i> <!-- Icono de engranaje (tecnológico) -->
    </div>

    <!-- Texto de carga -->
    <h4 class="mt-4 text-dark">Cargando tu tienda de tecnología</h4>
    <p class="text-muted">Estamos preparando los mejores productos para ti...</p>

    <!-- Barra de progreso (opcional para mejorar el efecto visual) -->
    <div class="progress mt-3" style="height: 10px;">
        <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 70%"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php if((($mensaje=Session::get('mensaje')) &&(($icono=Session::get('icono'))))): ?>
<script>
    Swal.fire({
        position: "top-end",
        icon: "<?php echo e($icono); ?>",
        title: "<?php echo e($mensaje); ?>",
        showConfirmButton: false,
        timer: 2500
    });
</script>
<?php endif; ?>
<?php echo $__env->make('adminlte::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views/vendor/adminlte/page.blade.php ENDPATH**/ ?>